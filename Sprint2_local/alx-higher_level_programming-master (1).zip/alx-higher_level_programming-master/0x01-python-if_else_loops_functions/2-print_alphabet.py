#!/usr/bin/python3
for i in range(97, 123):
    print("{0:c}".format(i), end="")
