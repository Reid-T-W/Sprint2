#!/usr/bin/python3
import sys
buf = "and that piece of art is useful - Dora Korpar, 2015-10-19\n"
sys.stderr.write(buf)
sys.exit(1)
